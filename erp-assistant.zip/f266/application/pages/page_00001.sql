prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5911239808873890743
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'EXAM'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(6037780335665711141)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'ERP AI ASSISTANT'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.querySelectorAll(',
'  ''.t-Region, .t-Region-body, .t-Region-bodyWrap, .t-Region-wrap''',
').forEach(function(el) {',
'  el.style.setProperty(''background-color'', ''rgba(255,255,255,0.35)'', ''important'');',
'});',
'',
'document.querySelectorAll(''.t-Region-header'').forEach(function(el) {',
'  el.style.setProperty(''background-color'', ''rgba(255,255,255,0.4)'', ''important'');',
'});',
'',
'document.querySelectorAll(',
'  ''textarea, .apex-item-textarea, .apex-item-wrapper--textarea textarea''',
').forEach(function(el) {',
'  el.style.setProperty(''background-color'', ''rgba(255,255,255,0.6)'', ''important'');',
'  el.style.setProperty(''color'', ''#00695c'', ''important'');',
'  el.style.setProperty(''-webkit-text-fill-color'', ''#00695c'', ''important'');',
'});',
'',
'document.querySelectorAll(',
'  ''.apex-item-display-only, .apex-item-wrapper--display-only''',
').forEach(function(el) {',
'  el.style.setProperty(''background-color'', ''rgba(255,255,255,0.6)'', ''important'');',
'  el.style.setProperty(''color'', ''#00695c'', ''important'');',
'});',
'',
'',
'',
'',
'',
'document.querySelectorAll(',
'  ''.apex-item-display-only, .display_only, .t-Form-itemText''',
').forEach(function(el) {',
'  el.style.setProperty(''color'', ''#1a4a5a'', ''important'');',
'  el.style.setProperty(''-webkit-text-fill-color'', ''#1a4a5a'', ''important'');',
'});',
'',
'',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@import url(''https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Syne:wght@400;600&display=swap'');',
'',
'/* ===== BACKGROUND ===== */',
'html, body, .t-Body, .t-Body-main, .t-Body-content,',
'.t-Body-wrap, .t-PageBody {',
'  background: linear-gradient(160deg, #b2dfdb, #80cbc4, #4db6ac) !important;',
'  background-attachment: fixed !important;',
'  min-height: 100vh !important;',
'  margin: 0 !important;',
'  font-family: ''Syne'', sans-serif !important;',
'}',
'',
'/* ===== NAVBAR ===== */',
'header, .t-Header, .t-Header *,',
'.t-NavigationBar, .t-NavigationBar * {',
'  background: rgba(0, 77, 64, 0.85) !important;',
'  border-bottom: 1px solid rgba(255,255,255,0.15) !important;',
'}',
'.t-Header a, .t-Header span, .t-Header button {',
'  color: #e0f2f1 !important;',
'}',
'.t-Header .t-Button,',
'.t-NavigationBar .t-Button {',
'  background: rgba(255,255,255,0.15) !important;',
'  border: 1px solid rgba(255,255,255,0.3) !important;',
'  color: #e0f2f1 !important;',
'  border-radius: 20px !important;',
'}',
'',
'/* ===== CONTENT WIDTH ===== */',
'.t-Body-contentInner {',
'  max-width: 780px !important;',
'  margin: 32px auto !important;',
'  padding: 0 24px !important;',
'}',
'',
'/* ===== REGION CARDS ===== */',
'.t-Region,',
'.t-Region-wrap,',
'.t-Region-bodyWrap {',
'  background: rgba(255, 255, 255, 0.35) !important;',
'  border: 1px solid rgba(255,255,255,0.6) !important;',
'  border-radius: 14px !important;',
'  overflow: hidden !important;',
'  margin-bottom: 20px !important;',
'  box-shadow: 0 4px 20px rgba(0,77,64,0.1) !important;',
'}',
'.t-Region-body {',
'  background: transparent !important;',
'  padding: 20px !important;',
'}',
'',
'/* ===== REGION HEADER ===== */',
'.t-Region-header {',
'  background: rgba(255,255,255,0.4) !important;',
'  border-bottom: 1px solid rgba(255,255,255,0.5) !important;',
'  padding: 12px 20px !important;',
'}',
'.t-Region-title {',
'  font-family: ''DM Mono'', monospace !important;',
'  font-size: 9px !important;',
'  letter-spacing: 0.2em !important;',
'  text-transform: uppercase !important;',
'  color: #00695c !important;',
'  background: transparent !important;',
'  border: none !important;',
'  border-radius: 0 !important;',
'  padding: 0 !important;',
'}',
'',
'/* ===== TEXTAREA ===== */',
'textarea,',
'textarea:hover,',
'textarea:focus,',
'textarea:active,',
'.apex-item-textarea,',
'.apex-item-wrapper--textarea textarea,',
'.apex-item-wrapper--textarea textarea:focus {',
'  background: rgba(255,255,255,0.6) !important;',
'  background-color: rgba(255,255,255,0.6) !important;',
'  color: #00695c !important;',
'  -webkit-text-fill-color: #00695c !important;',
'  caret-color: #00897b !important;',
'  border: 1px solid rgba(255,255,255,0.8) !important;',
'  border-radius: 8px !important;',
'  box-shadow: none !important;',
'  -webkit-box-shadow: none !important;',
'  outline: none !important;',
'  font-family: ''Syne'', sans-serif !important;',
'  font-size: 13px !important;',
'  line-height: 1.8 !important;',
'}',
'textarea::placeholder {',
'  color: #b2dfdb !important;',
'}',
'textarea:focus {',
'  border-color: #00897b !important;',
'}',
'textarea:-webkit-autofill {',
'  -webkit-box-shadow: 0 0 0px 1000px rgba(255,255,255,0.6) inset !important;',
'  -webkit-text-fill-color: #00695c !important;',
'}',
'',
'/* ===== SEND BUTTON ===== */',
'.t-Button, button[type="submit"] {',
'  background: #00695c !important;',
'  border: none !important;',
'  color: #e0f2f1 !important;',
'  font-family: ''DM Mono'', monospace !important;',
'  font-size: 10px !important;',
'  letter-spacing: 0.14em !important;',
'  text-transform: uppercase !important;',
'  border-radius: 6px !important;',
'  padding: 9px 22px !important;',
'  transition: all 0.2s !important;',
'}',
'.t-Button:hover {',
'  background: #004d40 !important;',
'}',
'',
'/* ===== CHAT REPLY ===== */',
'.apex-item-display-only,',
'.apex-item-wrapper--display-only {',
'  background: rgba(255,255,255,0.6) !important;',
'  background-color: rgba(255,255,255,0.6) !important;',
'  color: #00695c !important;',
'  -webkit-text-fill-color: #00695c !important;',
'  font-family: ''DM Mono'', monospace !important;',
'  font-size: 12px !important;',
'  line-height: 1.8 !important;',
'  border: 1px solid rgba(255,255,255,0.8) !important;',
'  border-radius: 8px !important;',
'  padding: 12px !important;',
'}',
'',
'/* ===== GLOBAL FOCUS RESET ===== */',
'*:focus {',
'  outline: none !important;',
'  box-shadow: none !important;',
'  -webkit-box-shadow: none !important;',
'}',
'',
'',
'',
'/* Match response text color to input text */',
'.apex-item-display-only,',
'.apex-item-wrapper--display-only,',
'.apex-item-display-only *,',
'.t-Form-itemText,',
'.display_only {',
'  color: #1a4a5a !important;',
'  -webkit-text-fill-color: #1a4a5a !important;',
'  font-family: ''Syne'', sans-serif !important;',
'  font-size: 13px !important;',
'}',
'',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'TAHMID'
,p_last_upd_yyyymmddhh24miss=>'20260412093932'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6037792982045711203)
,p_plug_name=>'ERP AI ASSISTANT'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_api.id(6037690589616711048)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6037895710103935801)
,p_plug_name=>'ERP AI Assistant'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6037695714955711051)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6037897785293935821)
,p_plug_name=>'Chat Window'
,p_region_css_classes=>'chat-window'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(6037695714955711051)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6037895969481935803)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6037895710103935801)
,p_button_name=>'SEND_MESSAGE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6037757831720711095)
,p_button_image_alt=>'Send'
,p_button_position=>'BODY'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6037898708956935831)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6037895710103935801)
,p_button_name=>'ADD_MEDICINE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(6037757831720711095)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Medicine'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P3_NAME:P1_USER_MESSAGE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6037895814099935802)
,p_name=>'P1_USER_MESSAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6037895710103935801)
,p_prompt=>'Ask ERP Assistant'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(6037756706592711092)
,p_item_css_classes=>'ai-input'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6037896054026935804)
,p_name=>'P1_AI_RESPONSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6037897785293935821)
,p_prompt=>'Assistant Reply'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(6037756706592711092)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6037898159157935825)
,p_name=>'Show Typing'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(6037895969481935803)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6037896155829935805)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCESS_CHATBOT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_message VARCHAR2(4000);',
'    v_product VARCHAR2(100);',
'    v_quantity NUMBER;',
'    v_expiry DATE;',
'    v_sales NUMBER;',
'BEGIN',
'',
'v_message := LOWER(:P1_USER_MESSAGE);',
'',
'-- INVENTORY CHECK',
'IF v_message LIKE ''%inventory%'' OR v_message LIKE ''%stock%'' THEN',
'',
'    SELECT product_name',
'    INTO v_product',
'    FROM inventory',
'    WHERE LOWER(v_message) LIKE ''%'' || LOWER(product_name) || ''%''',
'    FETCH FIRST 1 ROWS ONLY;',
'',
'    SELECT quantity',
'    INTO v_quantity',
'    FROM inventory',
'    WHERE LOWER(product_name) = LOWER(v_product);',
'',
'    :P1_AI_RESPONSE :=',
'    v_product || '' has '' || v_quantity || '' units available in inventory.'';',
'',
'',
'-- EXPIRY ALERT',
'ELSIF v_message LIKE ''%expire%'' OR v_message LIKE ''%expiry%'' THEN',
'',
'    SELECT product_name, expiry_date',
'    INTO v_product, v_expiry',
'    FROM inventory',
'    WHERE expiry_date < SYSDATE + 90',
'    FETCH FIRST 1 ROWS ONLY;',
'',
'    :P1_AI_RESPONSE :=',
'    v_product || '' will expire on '' || TO_CHAR(v_expiry,''DD-MON-YYYY'');',
'',
'',
'-- TOP SELLING MEDICINE',
'ELSIF v_message LIKE ''%top%'' OR v_message LIKE ''%most sold%'' THEN',
'',
'    SELECT product_name, SUM(quantity_sold)',
'    INTO v_product, v_sales',
'    FROM sales',
'    GROUP BY product_name',
'    ORDER BY SUM(quantity_sold) DESC',
'    FETCH FIRST 1 ROWS ONLY;',
'',
'    :P1_AI_RESPONSE :=',
'    ''Top selling medicine is '' || v_product ||',
'    '' with '' || v_sales || '' units sold.'';',
'',
'',
'-- SALES REPORT',
'ELSIF v_message LIKE ''%sales%'' THEN',
'',
'    SELECT SUM(amount)',
'    INTO v_sales',
'    FROM sales;',
'',
'    :P1_AI_RESPONSE :=',
'    ''Total sales recorded: '' || v_sales;',
'',
'',
'-- UNKNOWN QUESTION',
'ELSE',
'',
'    :P1_AI_RESPONSE :=',
'    ''I can help with:',
'     - inventory check',
'     - expiry alerts',
'     - sales report',
'     - top selling medicine'';',
'',
'END IF;',
'',
'EXCEPTION',
'WHEN NO_DATA_FOUND THEN',
'',
':P1_AI_RESPONSE := ''No matching data found in ERP database.'';',
'',
'END;',
''))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_api.id(6037895969481935803)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(6037898510886935829)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Generate Response'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_answer VARCHAR2(4000);',
'BEGIN',
'    SELECT *',
'    INTO v_answer',
'    FROM (',
'        SELECT NAME || '' (Stock: '' || INVENTORY || '', Expires: '' || TO_CHAR(EXPIRY_DATE, ''DD-MON-YYYY'') || '')'' AS result',
'        FROM MEDICINES2',
'        WHERE LOWER(NAME) LIKE ''%'' || LOWER(:P1_USER_MESSAGE) || ''%''',
'    )',
'    WHERE ROWNUM = 1;',
'',
unistr('    :P1_AI_RESPONSE := ''\D83D\DC8A: '' || v_answer;'),
'',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
unistr('        :P1_AI_RESPONSE := ''\274C No medicine found.'';'),
'    WHEN OTHERS THEN',
unistr('        :P1_AI_RESPONSE := ''\26A0\FE0F Error occurred: '' || SQLERRM;'),
'END;'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
