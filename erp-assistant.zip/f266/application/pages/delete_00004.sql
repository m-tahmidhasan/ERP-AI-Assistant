prompt --application/pages/delete_00004
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>5911239808873890743
,p_default_application_id=>266
,p_default_id_offset=>0
,p_default_owner=>'EXAM'
);
wwv_flow_api.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>4);
wwv_flow_api.component_end;
end;
/
